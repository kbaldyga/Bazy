-module(db_cart).
-compile(export_all).

