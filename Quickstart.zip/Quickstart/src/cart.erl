-module(cart).
-include_lib("nitrogen/include/hf.hrl").
-compile(export_all).

main() ->
    #template { file = ".templates/cart.html" } .
title() ->
    "Cart" .

cart_content_data() ->
    Content = case wf:session(koszyk) of
                  undefined -> [];
                  Set -> sets:to_list(Set)
              end,
    
